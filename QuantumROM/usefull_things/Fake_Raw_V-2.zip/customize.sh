# FakeRaw
# By AL NOMAN

FakeRaw() {
  find /odm -type d -exec mkdir -p /data/adb/modules_update/FakeRaw/{} \;
  find /product -type d -exec mkdir -p /data/adb/modules_update/FakeRaw/{} \;
  find /system -type d -exec mkdir -p /data/adb/modules_update/FakeRaw/{} \;
  find /vendor -type d -exec mkdir -p /data/adb/modules_update/FakeRaw/{} \;

}

FakeRaw